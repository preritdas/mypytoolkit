# My Tools

`tprint()` prints along with type.